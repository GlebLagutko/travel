export const CHANGE_LANGUAGE: string = "CHANGE_LANGUAGE"
